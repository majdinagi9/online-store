<?php 

define("ROOT_PATH",realpath(dirname(__FILE__))); 

define("BASE_URL", "http://localhost/akrm");

// http://ec2-34-248-33-150.eu-west-1.compute.amazonaws.com/akrm