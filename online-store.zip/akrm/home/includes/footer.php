<!DOCTYPE html>
<html>
  <head>
    <style>
      footer{
      padding: 10px 20px;
      background: #666;
      color: white;
      }
     
    </style>
  </head>
  <body>
    <footer>
      <p>Company © AKRM. All rights reserved.</p>
    </footer>
  </body>
</html>